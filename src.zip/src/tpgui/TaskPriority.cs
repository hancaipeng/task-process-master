﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace xworks.taskprocess
{
	enum TaskPriority
	{
		高 = 0,
		中,
		普通,
		低
	}
}
